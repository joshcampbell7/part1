package edu.leicester.co2103.domain;

public class ErrorInfo {
    public final String message;

    public ErrorInfo(String message) {
        this.message = message;
    }
}
